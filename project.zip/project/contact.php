
<html>
    <head>
        <title>Book Store</title>
				<meta name="viewport" content="width=device-width, initial-scale=1.0">

        <link rel="stylesheet" type="text/css" href="./styles/style.css">
		<style>
	
		
		</style>
    </head>    
    <body>
        <header>
            
            <div class="main">
				
                <ul>
                    <li class="active"><a href="index.php">HOME</a></li>
                    <li><a href="index.php">STORE</a></li>
                    <li><a href="cart.php">CART</a></li>                    
                    <li><a href="contact.php">CONTACT</a></li>
                </ul>
                <div class="title">
                <h1>Book Store</h1>
                
            	</div>
				<div class="address">
					<div class="add1">
				<p>651 Fairview Mall<br>Kitchener<br>+1-123-145-4785</p>
				</div>
				<div class="add1">
				<p>123 Conestoga Mall<br>Cambridge<br>+1-123-145-7895</p>
				</div>
				
				</div>
				
            </div>
			
            
    
        </header>
		<footer>
			Copyright &copy; BookStore 2020
		</footer>
    </body>
</html>    