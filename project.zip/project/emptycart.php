<?php
require('./database/mysqli_connect.php');
$q="delete from orders";
$r1=@mysqli_query($dbc,$q);
header('location:cart.php');
?>